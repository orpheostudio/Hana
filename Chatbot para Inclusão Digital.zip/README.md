
  # Chatbot para Inclusão Digital

  This is a code bundle for Chatbot para Inclusão Digital. The original project is available at https://www.figma.com/design/x34zFJvoPzCmj2UaAdL7yC/Chatbot-para-Inclus%C3%A3o-Digital.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  